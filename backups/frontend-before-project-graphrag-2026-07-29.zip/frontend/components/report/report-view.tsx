import { ReportActions } from "@/components/report/report-actions";
import { ReportBanner } from "@/components/ui/report-banner";
import { apiBaseUrl } from "@/lib/config";
import type { ComplianceReport, StoredReport } from "@/lib/types";

function buildUploadDownloadUrl(uploadId: string) {
  return `${apiBaseUrl}/api/uploads/${encodeURIComponent(uploadId)}/download`;
}

function groupFindings(report: ComplianceReport) {
  const buckets = {
    Major: report.findings.filter((finding) => finding.verdict === "Major"),
    Minor: report.findings.filter((finding) => finding.verdict === "Minor"),
    Compliant: report.findings.filter((finding) => finding.verdict === "Compliant"),
    "Needs More Evidence": report.findings.filter((finding) => finding.verdict === "Needs More Evidence"),
  };
  return buckets;
}

export function ReportView({ report }: { report: StoredReport }) {
  const structured = report.structured_report;

  if (!structured) {
    return (
      <div className="report-shell">
        <ReportBanner />
        <div className="panel">
          <h1>Report unavailable</h1>
          <p>{report.response_text}</p>
        </div>
      </div>
    );
  }

  const grouped = groupFindings(structured);

  return (
    <div className="report-shell">
      <ReportBanner />
      <section className="report-hero panel">
        <div><p className="eyebrow">Structured pre-audit report</p>
        <h1>Clause-grounded gap analysis</h1>
        <p>{structured.executive_summary}</p></div><span className="page-status"><i /> Report verified against retrieved context</span>
      </section>
      <ReportActions reportId={report.id} executiveSummary={structured.executive_summary} />
      <section className="report-summary-grid">
        {Object.entries(grouped).map(([label, findings]) => (
          <article key={label} className="metric-card">
            <span>{label}</span>
            <strong>{findings.length}</strong>
          </article>
        ))}
      </section>
      <section className="report-card-grid">
        {structured.findings.map((finding) => (
          <article
            key={`${finding.category}-${finding.clause_reference}`}
            className={`finding-card finding-${finding.verdict.toLowerCase().replaceAll(" ", "-")}`}
          >
            <div className="finding-head">
              <span className="status-pill">{finding.verdict}</span>
              <span className="confidence-pill">{finding.confidence} confidence</span>
            </div>
            <h3>{finding.category}</h3>
            <p className="clause-line">
              {finding.standard_name} · {finding.clause_reference}
            </p>
            <p>{finding.evidence_summary}</p>
            {(finding.references || []).length ? (
              <div className="finding-references">
                <strong>References</strong>
                <div className="reference-chip-list">
                  {(finding.references || []).map((reference, index) => {
                    const href =
                      reference.source_type === "upload" && reference.upload_id
                        ? buildUploadDownloadUrl(reference.upload_id)
                        : reference.source_url;
                    if (href) {
                      return (
                        <a
                          key={`${finding.category}-reference-${index}`}
                          className="file-chip inline-file-link"
                          href={href}
                          rel="noreferrer"
                          target="_blank"
                        >
                          {reference.label}
                        </a>
                      );
                    }
                    return (
                      <span key={`${finding.category}-reference-${index}`} className="file-chip">
                        {reference.label}
                      </span>
                    );
                  })}
                </div>
              </div>
            ) : null}
            <div className="finding-fix">
              <strong>Recommended fix</strong>
              <p>{finding.remediation}</p>
            </div>
          </article>
        ))}
      </section>
      <section className="report-two-up">
        <article className="panel">
          <h2>Next best questions</h2>
          <ul className="clean-list">
            {structured.next_best_questions.map((question) => (
              <li key={question}>{question}</li>
            ))}
          </ul>
        </article>
        <article className="panel">
          <h2>Recommended actions</h2>
          <ul className="clean-list">
            {structured.recommended_actions.map((action) => (
              <li key={action}>{action}</li>
            ))}
          </ul>
        </article>
      </section>
      {structured.current_web_findings?.length ? (
        <section className="panel">
          <div className="panel-head">
            <div>
              <p className="eyebrow">Current information check</p>
              <h2>Web-search MCP context used for this report</h2>
            </div>
            <span className="trace-badge">{structured.current_web_findings.length} items</span>
          </div>
          <ul className="clean-list">
            {structured.current_web_findings.map((finding, index) => (
              <li key={`report-web-${index}`}>
                {String(finding.title || finding.name || finding.url || "Current standards update")}
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
