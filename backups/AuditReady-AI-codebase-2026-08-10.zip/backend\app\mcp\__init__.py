"""Optional MCP integrations."""
