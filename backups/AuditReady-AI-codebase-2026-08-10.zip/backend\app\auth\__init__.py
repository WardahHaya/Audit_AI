"""Authentication services and dependencies."""
